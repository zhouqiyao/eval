This folder contains tmp files that are used in executing SQLs on the database.
